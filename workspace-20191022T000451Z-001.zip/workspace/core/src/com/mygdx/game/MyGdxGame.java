package com.mygdx.game;
import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.audio.Music;


///////////
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapRenderer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
////////////////

public class MyGdxGame extends ApplicationAdapter {
	public static SpriteBatch batch;
	public static Texture[] run, goomba;
	public static Mario mario;
	public static Goomba test;
	public static int timer;
	public static float timercount,splashcount;
	public static boolean walkRight, walkLeft, space,sprinting,fontremoved=false,gaming=false;
	public static float lolx, loly=0;
	public static BitmapFont font;
	public static int score,lives=3;
	public static Sound stomp,jump,die,gameover;
	public static Music overworld;

	//////////////
	public static TiledMap tiledMap;
	public static OrthographicCamera camera;
	public static TiledMapRenderer tiledMapRenderer;
	/////////////////

	@Override
	public void create () {
		stomp=Gdx.audio.newSound(Gdx.files.internal("stomp.wav"));
		jump=Gdx.audio.newSound(Gdx.files.internal("jump.wav"));
		die=Gdx.audio.newSound(Gdx.files.internal("die.wav"));
		gameover=Gdx.audio.newSound(Gdx.files.internal("gameover.wav"));
		overworld=Gdx.audio.newMusic(Gdx.files.internal("overworld.wav"));
		overworld.setLooping(true);
		overworld.setVolume(0.5f);
		timer=500;
		timercount=0;
		score=0;
		font=new BitmapFont(Gdx.files.internal("pixelminers.fnt"));
		Gdx.graphics.setWindowedMode(1024, 768);
		batch = new SpriteBatch();
		run = new Texture[]{new Texture("running0.png"),new Texture("running1.png"), new Texture("running2.png"),new Texture("running3.png"),new Texture("mariojump.png")};
		goomba=new Texture[]{new Texture("goomba1.png"), new Texture ("goomba2.png"), new Texture ("goombadead.png")};
		mario=new Mario(lolx,loly,run);
		test=new Goomba(900,0,goomba);

		/////
		camera = new OrthographicCamera();
		camera.setToOrtho(false,Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
		camera.update();
		tiledMap = new TmxMapLoader().load("level1.tmx");
		tiledMapRenderer = new OrthogonalTiledMapRenderer(tiledMap);

		//////////////////
	}
	

	@Override
	public void render () {
		
		splashscreen();

			///////
			
			camera.update();
			tiledMapRenderer.setView(camera);
			tiledMapRenderer.render();

			//////////



		if(gaming==true){
			Gdx.gl.glClearColor(92/255f,148/255f,252/255f,1);
			Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
			splashcount=0;
			mario.run(walkRight, walkLeft,sprinting);
			mario.jump();
			test.move(0);
			mario.checkcollide(test);
			space=false;
			sprinting=false;
			walkRight=false;
			walkLeft=false;
			if (Gdx.input.isKeyPressed(Input.Keys.RIGHT) || Gdx.input.isKeyPressed(Input.Keys.D)) {
				walkRight=true; 


			}

			else if (Gdx.input.isKeyPressed(Input.Keys.A) || Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
				walkLeft=true;
			}
			if (Gdx.input.isKeyPressed(Input.Keys.Z) || Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT)){
				sprinting=true;
			}


			batch.begin();
			mario.draw(batch);
			test.draw(batch);
			timer();
			if(lives>=1){
				font.draw(batch, "SCORE: "+score,50,750);
			} 
			batch.end();

			if(lives<1){
				if(fontremoved==false){
					font.dispose();
					mario.font1.dispose();
					test.font2.dispose();
					fontremoved=true;
					gameover.play();
				}
				font=new BitmapFont(Gdx.files.internal("pixelminers.fnt"));
				batch.begin();
				font.draw(batch,"GAME OVER",450,384);
				font.draw(batch,"PRESS SPACE TO CONTINUE",375,360);
				batch.end();
				test.die();
				score=0;
				timer=0;
				if (Gdx.input.isKeyPressed(Input.Keys.SPACE)){
					lives=3;
					overworld.play();
					create();
				}
			}

			if(mario.donedead==true){
				test.x-=1000;
				test.y-=1000;
				if (lives>=1){
					gaming=false;
					splashscreen();
					timer=500;
					score=0;

					mario=new Mario(lolx,loly,run);
					test=new Goomba(900,0,goomba);
					mario.dead=false;
				}
			}
		}



	}

	public void timer(){
		if (lives>=1){
			font.draw(batch, "TIME:"+timer,600,750);
		}
		if (mario.dead==false){
			timercount+=0.05;
		}
		if (timercount>=1){
			timer-=1;
			timercount=0;
		}
		if (timer<=0){
			mario.die();
		}
	}
	@Override
	public void dispose () {
		batch.dispose();
	}
	public static void splashscreen(){
		Gdx.gl.glClearColor(0,0,0,1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		batch.begin();
		batch.draw(run[0],475,330,30,37);
		font.draw(batch,"x "+lives,512,356);
		batch.end();
		splashcount+=0.05;

		if(splashcount>=100){
			gaming=true;
			overworld.play();
		}
	}
}

class Goomba{
	float x,y,fonty;
	float frame;
	private Texture[] walk;
	int size=37;
	float timeToGo;
	Rectangle hitbox,hurtbox;
	boolean dead;
	BitmapFont font2;
	public Goomba(float xx, float yy, Texture []pics){
		walk=pics;
		x=xx;
		y=yy;
		timeToGo=0;
		frame=0;
		dead=false;
		font2=new BitmapFont(Gdx.files.internal("pixelminers.fnt"));
	}
	public void draw(SpriteBatch sb){
		sb.draw(walk[Math.round(frame)],x,y,30,size);
		if (dead==true){
			font2.draw(sb, "100",x,fonty);
			fonty+=2;
			timeToGo+=0.1;
			if (fonty>y+100){
				fonty=10000;	}
		}
		if (timeToGo>=1){
			x=-1000;
			y=-1000;

		}
	}
	public void move(int way){
		if(dead==false){
			fonty=y+50;
			hitbox=new Rectangle(x,y,30,size);
			hurtbox=new Rectangle(x-5,y+50,40,size/2);
			if (way==0){
				x-=0.4;
				frame+=0.1;
				if (frame>=1){
					frame=0;
				}
			}
			if (way==1){
				x+=0.1;
				frame+=0.1;
				if (frame>=1){
					frame=0;
				}
			}
		}
		else{
			hurtbox.set(-10000,-1000,40,size/2);

		}
	}


	public void die(){
		frame=2;
		dead=true;
		MyGdxGame.score+=100;
		hitbox.set(-1000,-1000,40,size);

	}


}

class Mario{

	public float x,y;
	float frame, speed=2, framespeed=0.2f;
	private Texture[] run;
	int orientation=30;

	BitmapFont font1;
	boolean stop=false,singlejump=false, jump=false, dead=false,once=true,donedead=false;
	Rectangle hitbox;
	boolean soundonce=false;
	public Mario(float xx, float yy, Texture []pics){
		run = pics;
		x=xx;
		y=yy;
		frame = 0;
		font1=new BitmapFont(Gdx.files.internal("pixelminers.fnt"));
		hitbox=new Rectangle(x,y,30,37);

	}

	//ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	public void draw(SpriteBatch sb){
		sb.draw(run[Math.round(frame)],x,y,orientation,37);
		font1.draw(sb,"Lives: "+MyGdxGame.lives,250,750);
	}//ZZZZZZZZZZZZZZZZZZZZZZZZZZZz
	//++++++++++++++++++++++++++++++++++++
	public void run(boolean right, boolean left, boolean fast){
		if (dead==false){
			if (x>500) {
				MyGdxGame.camera.translate(8,0);
				x-=8;
				MyGdxGame.test.x-=8;
				
			}
			if (fast==true){
				speed+=0.1;
				framespeed=0.3f;
				if(speed>=8){
					speed=8;
				}

			}
			else{
				speed=2;
				framespeed=0.2f;
			}
			if (right==true){
				x+=speed;
				frame+=framespeed;

				if (frame>=3 && frame!=4){
					frame=1;
				}
				else if (jump==true){
					frame=4;
				}
				if(orientation<0){
					orientation*=-1;
					x-=30;
					hitbox.set(x-30,y,30,37);
				}
				else{
					hitbox.set(x,y,30,37);

				}


			}

			else if(left==true){
				x-=speed;
				frame+=framespeed;
				if (frame>=3 && frame!=4){
					frame=1;
				}
				else if (jump==true){
					frame=4;
				}
				if(orientation>0){
					orientation*=-1;
					x+=30;
					hitbox.set(x,y,30,37);

				}
				else{
					hitbox.set(x-30,y,30,37);

				}
			}
			else if(jump==false){frame=0;}
			else{frame=4;}
		}
	}//++++++++++++++++++++++++++++++++

	//---------------------------------------------------------------------------------------------------------------------
	public void jump(){
		if (dead==false){
			hitbox.setY(y);
			if (Gdx.input.isKeyPressed(Input.Keys.SPACE) && singlejump==true && y<200|| Gdx.input.isKeyPressed(Input.Keys.X) && singlejump==true) {
				if(dead==false){	
					jump=true;
				}
			}
			else {
				jump=false;
			}
			if (y>2 && jump==false || y>0 && stop==true ||singlejump==false){
				if(jump!=true){
					y-=8;	
				}
			}

			else if(jump==true && singlejump==true){
				y+=8;	 
				if(soundonce==false){
					MyGdxGame.jump.play();
				}
				soundonce=true;
				if(y>200){
					stop=true;
					singlejump=false;
				}

			}
			if(jump==false){
				singlejump=false;
				stop=true;
			}

			if(y<=2){
				y=4;
				stop=false;
				singlejump=true;
				soundonce=false;
			}
		}
	}
	//------------------------------------------------------------------------------------------------------------------
	public void checkcollide(Goomba enemy){

		if (hitbox.overlaps(enemy.hitbox)){
			enemy.hitbox.set(-200,-200,20,20);
			die();
		}
		if (hitbox.overlaps(enemy.hurtbox)){
			y+=25;
			enemy.die();
			MyGdxGame.stomp.play();

		}
	}
	public void die(){
		if(dead==false){
			y=400;
			MyGdxGame.lives-=1;
			MyGdxGame.overworld.stop();
			if(MyGdxGame.lives>=1){
				MyGdxGame.die.play();
				frame=5;

			}
			if(orientation<0){orientation*=-1;}
		}
		y-=15;

		dead=true;
		if(y<-200){
			donedead=true;
		}


	}

}






