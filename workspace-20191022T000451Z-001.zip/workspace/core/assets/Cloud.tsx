<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Cloud" tilewidth="16" tileheight="16" tilecount="4" columns="2">
 <image source="Sprites/cloud.png" width="46" height="32"/>
</tileset>
