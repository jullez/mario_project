<?xml version="1.0" encoding="UTF-8"?>
<tileset name="52571" tilewidth="16" tileheight="16" tilecount="924" columns="33">
 <image source="52571.png" width="528" height="448"/>
</tileset>
